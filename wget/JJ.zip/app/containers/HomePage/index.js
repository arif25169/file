/*
 * HomePage
 *
 * This is the first thing users see of our App, at the '/' route
 *
 * NOTE: while this component should technically be a stateless functional
 * component (SFC), hot reloading does not currently support SFCs. If hot
 * reloading is not a necessity for you then you can refactor it and remove
 * the linting exception.
 */

import React from 'react';
import { FormattedMessage } from 'react-intl';
import { Grid, Row, Col, Panel, Button, ButtonGroup, ButtonToolbar, SplitButton, DropdownButton, MenuItem, Pagination, Pager } from 'react-bootstrap';
import BsCarousel from 'components/Elements/Carousel';
import SubmitButton from 'components/SubmitButton';
import messages from './messages';

export default class HomePage extends React.PureComponent { // eslint-disable-line react/prefer-stateless-function
  render() {
    function tst() {
      alert('test button submit');
    };
    function tst2() {
      alert('test button submit 2');
    };
    return (
      <div>
        <h1>
          <FormattedMessage {...messages.header} />
        </h1>
        <h1>This project is for Netizen IT Ltd.</h1>
        <br />
        <SubmitButton label='Test' onSubmitForm={tst} />
        <SubmitButton label='Test 2' onSubmitForm={tst2} />
        <Button>Basic </Button>
        <Button bsStyle="warning">Warning</Button>
        <Button bsStyle="danger">Danger</Button>
        <Button bsStyle="danger">Danger</Button>
        <BsCarousel label="My custom label" />
      </div>
    );
  }
}
