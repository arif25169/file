// import React from 'react';
// import { shallow } from 'enzyme';

// import { Form } from '../index';

describe('<Form />', () => {
  it('Expect to have unit tests specified', () => {
    expect(true).toEqual(false);
  });
});
