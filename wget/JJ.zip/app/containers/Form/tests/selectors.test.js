// import { fromJS } from 'immutable';
// import { selectFormDomain } from '../selectors';

describe('selectFormDomain', () => {
  it('Expect to have unit tests specified', () => {
    expect(true).toEqual(false);
  });
});
