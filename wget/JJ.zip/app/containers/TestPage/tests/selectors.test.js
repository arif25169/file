// import { fromJS } from 'immutable';
// import { selectTestPageDomain } from '../selectors';

describe('selectTestPageDomain', () => {
  it('Expect to have unit tests specified', () => {
    expect(true).toEqual(false);
  });
});
