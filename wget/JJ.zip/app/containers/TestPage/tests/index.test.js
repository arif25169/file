// import React from 'react';
// import { shallow } from 'enzyme';

// import { TestPage } from '../index';

describe('<TestPage />', () => {
  it('Expect to have unit tests specified', () => {
    expect(true).toEqual(false);
  });
});
