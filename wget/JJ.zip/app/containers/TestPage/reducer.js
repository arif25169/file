/*
 *
 * TestPage reducer
 *
 */

import { fromJS } from 'immutable';
import {
  CHANGE_USERNAME,
  CHANGE_PASSWORD,
  CHANGE_ADDRESS,
  SUBMIT_LOGIN,


} from './constants';

const initialState = fromJS({});

function testPageReducer(state = initialState, action) {
  switch (action.type) {
    case CHANGE_USERNAME:
      return state.set('username', action.name);
    case CHANGE_PASSWORD:
      return state.set('password', action.password);
      case CHANGE_ADDRESS:
      return state.set('address', action.address);
    
    default:
      return state;
  }
}

export default testPageReducer;
