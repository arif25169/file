import { createSelector } from 'reselect';

/**
 * Direct selector to the testPage state domain
 */
const selectTestPageDomain = (state) => state.get('testPage');

/**
 * Other specific selectors
 */


/**
 * Default selector used by TestPage
 */

const makeSelectUserName = () => createSelector(
  selectTestPageDomain,
  (testState) => testState.get('username')
);

const makeSelectPassword = () => createSelector(
  selectTestPageDomain,
  (testState) => testState.get('password')
);
const makeSelectAddress= () => createSelector(
  selectTestPageDomain,
  (testState) => testState.get('address')
);



export {
  selectTestPageDomain,
  makeSelectUserName,
  makeSelectPassword,
  makeSelectAddress
 
};
