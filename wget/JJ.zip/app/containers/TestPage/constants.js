/*
 *
 * TestPage constants
 *
 */

export const CHANGE_USERNAME = 'app/TestPage/CHANGE_USERNAME';
export const CHANGE_PASSWORD = 'app/TestPage/CHANGE_PASSWORD';
export const CHANGE_ADDRESS = 'app/TestPage/CHANGE_ADDRESS';
export const SUBMIT_LOGIN = 'app/TestPage/SUBMIT_LOGIN';

