export default () => {

    if (!$.fn.jqGrid) return;

    // JSON EXAMPLE
    // ---------------------

    var gridJSON = $("#jqGridJSON");

    gridJSON.jqGrid({
               url: 'server/jqgrid.json',
				// we set the changes to be made at client side using predefined word clientArray
                editurl: 'clientArray',
                datatype: "json",
                colModel: [
                    {
						label: 'Customer ID',
                        name: 'CustomerID',
                        width: 75,
						key: true,
						editable: true,
						editrules : { required: true}
                    },
                    {
						label: 'Company Name',
                        name: 'CompanyName',
                        width: 140,
                        editable: true // must set editable to true if you want to make the field editable
                    },
                    {
						label : 'Phone',
                        name: 'Phone',
                        width: 100,
                        editable: true
                    },
                    {
						label: 'Postal Code',
                        name: 'PostalCode',
                        width: 80,
                        editable: true
                    },
                    {
						label: 'City',
                        name: 'City',
                        width: 140,
                        editable: true
                    }
                ],
				sortname: 'CustomerID',
				sortorder : 'asc',
				loadonce: true,
				viewrecords: true,
                width: 780,
                height: 200,
                rowNum: 10,
                pager: "#jqGridJSONPager"
            });
			gridJSON.navGrid('#jqGridJSONPager',
		
		
                { edit: true, add: true, del: true, search: false, refresh: false, view: false, position: "left", cloneToTop: false },
                // options for the Edit Dialog
                {
                    editCaption: "The Edit Dialog",
                    recreateForm: true,
					//checkOnUpdate : true,
					//checkOnSubmit : true,
					beforeSubmit : function( postdata, form , oper) {
						if( confirm('Are you sure you want to update this row?') ) {
							// do something
							return [true,''];
						} else {
							return [false, 'You can not submit!'];
						}
					},
                    closeAfterEdit: true,
                    errorTextFormat: function (data) {
                        return 'Error: ' + data.responseText
                    }
                },
                // options for the Add Dialog
                {
                    closeAfterAdd: true,
                    recreateForm: true,
                    errorTextFormat: function (data) {
                        return 'Error: ' + data.responseText
                    }
                },
                // options for the Delete Dailog
                {
                    errorTextFormat: function (data) {
                        return 'Error: ' + data.responseText
                    }
                }
			
			);
			
		

    // NESTED EXAMPLE
    // ---------------------

    var gridTree = $('#jqGridTree');

    gridTree.jqGrid({
        url: "server/jqgrid-tree.json",
        colModel: [{
            name: "category_id",
            index: "accounts.account_id",
            sorttype: "int",
            key: true,
            hidden: true,
            width: 60
        }, {
            name: "name",
            index: "name",
            sorttype: "string",
            label: "Name",
            width: 160
        }, {
            name: "price",
            index: "price",
            sorttype: "numeric",
            label: "Price",
            width: 90,
            align: "right"
        }, {
            name: "qty_onhand",
            index: "qty_onhand",
            sorttype: "int",
            label: "Qty",
            width: 90,
            align: "right"
        }, {
            name: "color",
            index: "color",
            sorttype: "string",
            label: "Color",
            width: 70
        }, {
            name: "lft",
            hidden: true
        }, {
            name: "rgt",
            hidden: true
        }, {
            name: "level",
            hidden: true
        }, {
            name: "uiicon",
            hidden: true
        }],
        // width: "780",
        hoverrows: false,
        // viewrecords: false,
        // gridview: true,
        height: "auto",
        sortname: "lft",
        loadonce: true,
        rowNum: 30,
        // scrollrows: true,
        // enable tree grid
        treeGrid: true,
        // which column is expandable
        ExpandColumn: "name",
        // datatype
        treedatatype: "json",
        // the model used
        treeGridModel: "nested",
        // configuration of the data comming from server
        treeReader: {
            left_field: "lft",
            right_field: "rgt",
            level_field: "level",
            leaf_field: "isLeaf",
            expanded_field: "expanded",
            loaded: "loaded",
            icon_field: "icon"
        },
        sortorder: "asc",
        datatype: "json",
        pager: "#jqGridTreePager",
        viewrecords: true, // show the current page, data rang and total records on the toolbar
        autowidth: true,
        shrinkToFit: true,
        caption: "Nested Example"
    });

    $(window).on('resize', function() {
        var width = $('.jqgrid-responsive').width();
        gridJSON.setGridWidth(width);
        gridTree.setGridWidth(width);
    }).resize();

}