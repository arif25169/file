import React from "react";
import 'react-bootstrap-table-next/dist/react-bootstrap-table2.min.css';
import BootstrapTable from "react-bootstrap-table-next";
import { Grid, Row, Col, Button } from 'react-bootstrap';
import cellEditFactory from 'react-bootstrap-table2-editor';

/**
 * @author Arif Hasan <arif25169@gmail.com>
 */

class ActionFormatter extends React.Component {
  render() {
    return (
      <div className="startup">
        <Button bsStyle="btn btn-green" bsSize="small"> <em className="fa fa-trash-o"></em></Button>
      </div>
    );
  }
}

function actionFormatter(cell, row) {
  return <ActionFormatter />;
}

const columns = [
  {
    dataField: "name",
    text: "Type",
    headerAlign: 'center',
    editable: false
  },
  {
    dataField: "price",
    text: "Quantity",
    headerAlign: 'center'
  },
  {
    formatter: actionFormatter,
    text: "Action",
    headerAlign: 'center',
    editable: false
  }
];
const products = [
  { name: "Academic year", price: 0 },
  { name: "Session", price: 0 },
  { name: "Class", price: 0 },
  { name: "Group", price: 0 },
  { name: "Shift", price: 0 },
  { name: "Section", price: 0 },
  { name: "Category", price: 0 }
]

const CaptionElement = () => <h5 style={{ textAlign: 'center' }}><b>Academic Year</b> <p> Total Count: 03 </p></h5>;

export default class StartUpModal extends React.Component {
  render() {
    return (
      <div className="startuptable">
        <BootstrapTable
          // className="container"
          keyField="id"
          data={products}
          columns={columns}
          caption={<CaptionElement />}
          striped
          cellEdit={cellEditFactory({
            mode: 'click',
            blurToSave: true
          })}
        />
        <br/>
         hellow world
      </div>
        
    );

  }
}
