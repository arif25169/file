export default () => {

    $('form[data-parsley-validate]').parsley();

}
