// import React from 'react';
// import { shallow } from 'enzyme';

// import ModalExample from '../index';

describe('<ModalExample />', () => {
  it('Expect to have unit tests specified', () => {
    expect(true).toEqual(false);
  });
});
