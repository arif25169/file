import React from 'react';
import { render } from 'react-dom';
import Button from 'material-ui/Button';


export default class Material extends React.Component {
  render() {
  return (
   <div>
   <Button variant="raised" color="primary">
   Hi
    </Button>
    <br/>
    <br/>
    <br/>
     <Button variant="raised" color="primary">
   Hi
    </Button>
  </div>
  );
}
}