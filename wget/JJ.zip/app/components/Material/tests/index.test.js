// import React from 'react';
// import { shallow } from 'enzyme';

// import Material from '../index';

describe('<Material />', () => {
  it('Expect to have unit tests specified', () => {
    expect(true).toEqual(false);
  });
});
