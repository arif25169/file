import React from 'react';

class Footer extends React.Component {

    render() {
        return (
            <footer>
                <span>&copy; 2017 - Angle</span>
            </footer>
        );
    }

}

export default Footer;
