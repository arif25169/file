// import React from 'react';
// import { shallow } from 'enzyme';

// import StartUpModalButton from '../index';

describe('<StartUpModalButton />', () => {
  it('Expect to have unit tests specified', () => {
    expect(true).toEqual(false);
  });
});
