// import React from 'react';
// import { shallow } from 'enzyme';

// import StartUpTable from '../index';

describe('<StartUpTable />', () => {
  it('Expect to have unit tests specified', () => {
    expect(true).toEqual(false);
  });
});
