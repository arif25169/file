import React from "react";
import 'react-bootstrap-table-next/dist/react-bootstrap-table2.min.css';
import BootstrapTable from "react-bootstrap-table-next";
import cellEditFactory from 'react-bootstrap-table2-editor';
import { Grid, Row, Col } from 'react-bootstrap';
import StartUpModalButton from 'components/StartUpModalButton';

/**
 * @author Arif Hasan <arif25169@gmail.com>
 */



class ActionFormatter extends React.Component {
  render() {
    return (
      <div className="startup">
        <StartUpModalButton />
      </div>
    );
  }
}

function actionFormatter(cell, row) {
  return <ActionFormatter />;
}

function onAfterInsertRow(row) {
  let newRowStr = '';

  for (const prop in row) {
    newRowStr += prop + ': ' + row[prop] + ' \n';
  }
 
}

const options = {
  afterInsertRow: onAfterInsertRow   // A hook for after insert rows
};


const columns = [
  {
    dataField: "name",
    text: "Type",
    headerAlign: 'center'
  },
  {
    dataField: "quantity",
    text: "Quantity",
    headerAlign: 'center'
  },
  {
    formatter: actionFormatter,
    text: "Action",
    headerAlign: 'center'
  },
  {
    formatter: onAfterInsertRow,
    text: "Action",
    headerAlign: 'center'
  }
];
const products = [
  { name: "Academic year", quantity: 0 },
  { name: "Session", quantity: 0 },
  { name: "Class", quantity: 0 },
  { name: "Group", quantity: 0 },
  { name: "Shift", quantity: 0 },
  { name: "Section", quantity: 0 },
  { name: "Category", quantity: 0 }
]

const CaptionElement = () => <h5 style={{ textAlign: 'center' }}><b>Monitor</b></h5>;

export default class StartUpTable extends React.Component {
  render() {
    return (
      <div className="startuptable">
        <BootstrapTable
          className="container"
          keyField="id"
          data={products}
          insertRow={ true } 
          search={true}
          options={ options }
          columns={columns}
          caption={<CaptionElement />}
          striped
        />
      </div>

      
    );

  }
}
