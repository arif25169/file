import React from 'react';
import StartUpTable from 'components/StartUpTable';
import { Grid, Row, Col, Panel, Button, ButtonGroup, ButtonToolbar, SplitButton, DropdownButton, MenuItem, Pagination, Pager, PageItem, Alert, ProgressBar, OverlayTrigger, Tooltip, Popover, Modal } from 'react-bootstrap';

class Maintenance extends React.Component {
    
    constructor(props, context) {
        super(props, context);
        this.state = {
            showModal: false
        };
    }

    close() {
        this.setState({
            showModal: false
        });
    }

    open() {
        this.setState({
            showModal: true
        });
    }

    render() {
        let closeModal = () => this.setState({ open: false })
        let saveAndClose = () => {
            this.setState({ open: false })
        }

        return (

            <div>
                <p>Click to get the full Modal experience!</p>
                <Button bsStyle="primary" bsSize="large" onClick={this.open.bind(this)}>
                    Launch demo modal
                            </Button>
                <Modal show={this.state.showModal} onHide={this.close.bind(this)}>
                    <Modal.Header closeButton>
                        <Modal.Title>Modal heading</Modal.Title>
                    </Modal.Header>
                    <Modal.Body>
                    <StartUpTable />
                    </Modal.Body>
                    <Modal.Footer>
                        <Button onClick={this.close.bind(this)}>Close</Button>
                    </Modal.Footer>
                </Modal>
            </div>
        )
    }
}
export default Maintenance;