// import React from 'react';
// import { shallow } from 'enzyme';

// import StartUpTable2 from '../index';

describe('<StartUpTable2 />', () => {
  it('Expect to have unit tests specified', () => {
    expect(true).toEqual(false);
  });
});
