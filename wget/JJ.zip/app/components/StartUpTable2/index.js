import React from "react";
import 'react-bootstrap-table-next/dist/react-bootstrap-table2.min.css';
import paginationFactory from 'react-bootstrap-table2-paginator';
import BootstrapTable from "react-bootstrap-table-next";
import { Grid, Row, Col } from 'react-bootstrap';

/**
 * 
 */

class ActionFormatter extends React.Component {
  render() {
    return (
      <div className="startup">
        <button className='btn btn-info'><em className="icon-note"></em></button>
      </div>
    );
  }
}

function actionFormatter(cell, row) {
  return <ActionFormatter />;
}

const columns = [
  {
    dataField: "name",
    text: "Type",
    headerAlign: 'center'
  },
  {
    dataField: "quantity",
    text: "Quantity",
    headerAlign: 'center'
  },
  {
    formatter: actionFormatter,
    text: "Action",
    headerAlign: 'center'
  }
];
const products = [
  { name: "Academic year", quantity: 0 },
  { name: "Session", quantity: 0 },
  { name: "Class", quantity: 0 },
  { name: "Group", quantity: 0 },
  { name: "Shift", quantity: 0 },
  { name: "Section", quantity: 0 },
  { name: "Category", quantity: 0 }
]
const options = {
  paginationSize: 4,
  pageStartIndex: 0,
  // alwaysShowAllBtns: true, // Always show next and previous button
  // withFirstAndLast: false, // Hide the going to First and Last page button
  // hideSizePerPage: true, // Hide the sizePerPage dropdown always
  // hidePageListOnlyOnePage: true, // Hide the pagination list when only one page
  firstPageText: 'First',
  prePageText: 'Back',
  nextPageText: 'Next',
  lastPageText: 'Last',
  nextPageTitle: 'First page',
  prePageTitle: 'Pre page',
  firstPageTitle: 'Next page',
  lastPageTitle: 'Last page',
  sizePerPageList: [{
    text: '5', value: 5
  }, {
    text: '10', value: 10
  }, {
    text: 'All', value: products.length
  }] // A numeric array is also available. the purpose of above example is custom the text
};


const CaptionElement = () => <h4 style={{ textAlign: 'center' }}>Monitor<br /></h4>;

export default class StartUpTable2 extends React.Component {
  render() {
    return (
      <div className="startuptable">
        <BootstrapTable
          className="container"
          keyField="id"
          data={products}
          columns={columns}
          // caption={<CaptionElement />}
          pagination={ paginationFactory(options) }
          striped
        />
      </div>
    );

  }
}
