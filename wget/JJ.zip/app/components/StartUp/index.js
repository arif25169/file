import React from 'react';
import ContentWrapper from '../Layout/ContentWrapper';
import StartUpTable from 'components/StartUpTable';
import StartUpTable2 from 'components/StartUpTable2';
import StartUpForm from 'components/StartUpForm';
import Material from 'components/Material';
import StartUpModal from 'components/StartUpModal';
import { Row, Col, Panel } from 'react-bootstrap';

class StartUp extends React.Component {

  render() {

    return (
      <ContentWrapper>

        <Row>

          <Col sm={6}>
            <Panel>
              <StartUpForm />
            </Panel>
          </Col>

          <Col sm={6}>
            <Panel>

              <StartUpTable />

            </Panel>
          </Col>

        </Row>

        <Row>



          <Panel>

            <Material />

          </Panel>


        </Row>

        <Row>



          <Panel>

            <StartUpTable2 />

          </Panel>


        </Row>

      </ContentWrapper >
    );
  }

}

export default StartUp;
