import React from 'react';
import ContentWrapper from '../Layout/ContentWrapper';
import { Grid, Row, Col, Panel, Button, FormControl, FormGroup, InputGroup, DropdownButton, MenuItem } from 'react-bootstrap';

class StartUpForm extends React.Component {

  render() {

    return (
      <ContentWrapper>

        <br />
        <form role="form">
          <FormGroup>
            <label>Type <span className="starcolor"> *</span> </label>
            <FormControl componentClass="select" required="required" name="account" className="form-control m-b">
              <option>Option 1</option>
              <option>Option 2</option>
              <option>Option 3</option>
              <option>Option 4</option>
            </FormControl>
          </FormGroup>
          <FormGroup>
            <label>Select<span className="starcolor"> *</span></label>
            <FormControl componentClass="select" required="required" name="account" className="form-control m-b">
              <option>Option 1</option>
              <option>Option 2</option>
              <option>Option 3</option>
              <option>Option 4</option>
            </FormControl>
          </FormGroup>
          <div className="required"><span className="starcolor"> *</span> Required fields</div>
          <div className="savestartup">
          <Button bsClass="btn btn-labeled btn-green btn-sm">
                        <span className="btn-label"><i className="fa fa-save"></i></span> Save
                    </Button>
            {/* <Button type="submit" bsClass="btn btn-green" className="btn-lg"><i className="fa fa-save "> Save</i></Button> */}
          </div>
        </form>

      </ContentWrapper>
    );
  }

}

export default StartUpForm;
